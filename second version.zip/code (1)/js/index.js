async function LoadCurrentAndDefaultData() {
    localStorage.setItem('stu_data', JSON.stringify({ 2018: [], 2019: [], 2020: [], 2021: [] }));
    const loadData = await LoadAndFetch(2018);
    const fetchData = await LoadAndFetch(2022);

    const stu_data = JSON.parse(localStorage.getItem('stu_data'));
    stu_data[2018] = loadData;
    stu_data[2022] = fetchData;
    localStorage.setItem('stu_data', JSON.stringify(stu_data));

    return stu_data;
}

async function SetInitialLoading() {
    AddEvntListener();
    const stu_data = await LoadCurrentAndDefaultData();
    for (let i = 1; i <= 7; i++) {
        document.getElementById(`std_cur_${i}`).innerHTML = `${stu_data[2022][i - 1]['name']} ${canculateHours(stu_data[2022][i - 1]['time'])}`
        document.getElementById(`std_${i}`).innerHTML = `${stu_data[2018][i - 1]['name']} ${canculateHours(stu_data[2018][i - 1]['time'])}`
    }
    LoadDataAccordingYear();
    setClock();

}

SetInitialLoading();