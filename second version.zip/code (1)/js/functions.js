async function LoadAndFetch(year) {
    const responce = await fetch(`https://introweb.tech/cse134-final/fake-data.php/?year=${year}`);
    const data = await responce.json();
    data.sort(function (a, b) { return a.time - b.time; });
    return data;
}

function canculateHours(given_seconds) {
    hours = Math.floor(given_seconds / 3600);
    minutes = Math.floor((given_seconds - (hours * 3600)) / 60);
    seconds = given_seconds - (hours * 3600) - (minutes * 60);

    timeString = hours.toString().padStart(2, '0') + ':' +
        minutes.toString().padStart(2, '0') + ':' +
        seconds.toString().padStart(2, '0');

    return timeString
}

function setClock() {
    setInterval(() => {
        let currentDay = new Date();
        let secound = currentDay.getSeconds() + (60 * (currentDay.getMinutes() + (60 * currentDay.getHours())));
        document.getElementById('clock').innerHTML = `${canculateHours(86400 - secound)}`
    }, 1000)
}

function LoadDataAccordingYear() {
    const years = [2018, 2019, 2020, 2021];
    years.map(async (item) => {
        const loadData = await LoadAndFetch(item);
        const stu_rank_data = JSON.parse(localStorage.getItem('stu_data'));
        stu_data[item] = loadData;

        localStorage.setItem('stu_data', JSON.stringify(stu_rank_data));
        return item;
    })
}

function AddEvntListener() {
    document.getElementById('button').addEventListener('click', (_) => {
        document.getElementById('model').classList.remove('hideModel')
        document.getElementById('model').addEventListener('click', () => {
            document.getElementById('model').classList.add('hideModel')
        })
    })

    document.getElementById('year_option').addEventListener('change', async (event) => {
        const stu_data = JSON.parse(localStorage.getItem('stu_data'));
        if (stu_data[event.target.value].length == 0) {
            const data = await LoadAndFetch(event.target.value);
            stu_data[event.target.value] = data;
            localStorage.setItem('stu_data', JSON.stringify(stu_data));
        }
        for (let i = 1; i <= 7; i++) {
            document.getElementById(`std_${i}`).innerHTML = `${stu_data[event.target.value][i - 1]['name']} ${canculateHours(stu_data[event.target.value][i - 1]['time'])}`
        }
    })
}